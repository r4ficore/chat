import { ModelId } from "../types";

// NOTE: DeepSeek uses an OpenAI-compatible API structure.
// You need to set REACT_APP_DEEPSEEK_API_KEY or process.env.DEEPSEEK_API_KEY
const API_KEY = process.env.DEEPSEEK_API_KEY || ''; 
const BASE_URL = 'https://api.deepseek.com/v1/chat/completions';

/**
 * Streams content from the DeepSeek API.
 * This is a "readiness" implementation. It assumes standard OpenAI stream format.
 */
export async function* streamDeepSeekResponse(
  prompt: string,
  model: string = ModelId.DEEPSEEK_CHAT,
  systemInstruction?: string
): AsyncGenerator<string, void, unknown> {
  if (!API_KEY) {
    yield "DeepSeek API Key is missing. Please configure DEEPSEEK_API_KEY.";
    return;
  }

  try {
    const response = await fetch(BASE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      },
      body: JSON.stringify({
        model: model,
        messages: [
          ...(systemInstruction ? [{ role: 'system', content: systemInstruction }] : []),
          { role: 'user', content: prompt }
        ],
        stream: true
      })
    });

    if (!response.ok) {
      throw new Error(`DeepSeek API Error: ${response.statusText}`);
    }

    if (!response.body) throw new Error("No response body");

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.trim() === 'data: [DONE]') return;
        if (line.startsWith('data: ')) {
          try {
            const json = JSON.parse(line.slice(6));
            const content = json.choices[0]?.delta?.content;
            if (content) {
              yield content;
            }
          } catch (e) {
            console.error('Error parsing DeepSeek stream chunk', e);
          }
        }
      }
    }
  } catch (error) {
    console.error("DeepSeek API Error:", error);
    yield "I encountered an error while processing your request with DeepSeek. Please check your API configuration.";
  }
}