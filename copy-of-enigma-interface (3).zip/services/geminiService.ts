import { GoogleGenAI, Content, Part } from "@google/genai";
import { ModelId, Message } from "../types";

// Initialize the client strictly with the environment variable
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Streams content from the Gemini API with chat history.
 * 
 * @param history The conversation history.
 * @param model The model identifier to use.
 * @param systemInstruction Optional system instruction.
 * @yields Chunks of generated text.
 */
export async function* streamGeminiResponse(
  history: Message[], 
  model: string = ModelId.GEMINI_FLASH,
  systemInstruction?: string
): AsyncGenerator<string, void, unknown> {
  try {
    // Map internal Message type to GenAI SDK Content type
    const contents: Content[] = history.map(msg => {
      const parts: Part[] = [];
      
      // Add text part
      if (msg.text) {
        parts.push({ text: msg.text });
      }

      // Add image part if it exists and looks like a data URI
      if (msg.imageUrl && msg.imageUrl.startsWith('data:image')) {
        const [meta, data] = msg.imageUrl.split(',');
        const mimeType = meta.split(':')[1].split(';')[0];
        
        parts.push({
          inlineData: {
            mimeType: mimeType,
            data: data
          }
        });
      }

      return {
        role: msg.role,
        parts: parts
      };
    });

    const responseStream = await ai.models.generateContentStream({
      model: model,
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7, 
      }
    });

    for await (const chunk of responseStream) {
      const text = chunk.text;
      if (text) {
        yield text;
      }
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    yield " [System Error: Unable to connect to Gemini API. Please check your API Key.]";
  }
}