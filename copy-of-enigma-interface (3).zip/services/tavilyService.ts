
/**
 * Service to interact with the Tavily API for web search grounding.
 */
const TAVILY_API_URL = 'https://api.tavily.com/search';
const API_KEY = process.env.TAVILY_API_KEY || '';

interface TavilySearchResult {
  title: string;
  url: string;
  content: string;
  score: number;
}

interface TavilyResponse {
  results: TavilySearchResult[];
  answer?: string;
  query: string;
}

/**
 * Performs a web search using Tavily API.
 * 
 * @param query The user's search query.
 * @returns A formatted string containing search context.
 */
export async function searchTavily(query: string): Promise<string> {
  if (!API_KEY) {
    console.warn("Tavily API Key is missing. Set process.env.TAVILY_API_KEY to use web search.");
    return "";
  }

  try {
    const response = await fetch(TAVILY_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        api_key: API_KEY,
        query: query,
        search_depth: "basic",
        include_answer: true,
        max_results: 5
      })
    });

    if (!response.ok) {
      throw new Error(`Tavily API Error: ${response.statusText}`);
    }

    const data: TavilyResponse = await response.json();
    
    // Format the results into a context string for the LLM
    let context = "Web Search Results:\n\n";
    
    if (data.answer) {
      context += `Direct Answer: ${data.answer}\n\n`;
    }

    data.results.forEach((result, index) => {
      context += `Source ${index + 1}: ${result.title}\nURL: ${result.url}\nContent: ${result.content}\n\n`;
    });

    return context;

  } catch (error) {
    console.error("Tavily Search Failed:", error);
    return "";
  }
}
