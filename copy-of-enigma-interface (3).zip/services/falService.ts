import { ImageGenerationSettings } from "../types";

// NOTE: Ensure REACT_APP_FAL_KEY or process.env.FAL_KEY is set
const FAL_KEY = process.env.FAL_KEY || '';

const ENDPOINTS = {
  'flux-dev': 'https://fal.run/fal-ai/flux/dev',
  'nano-banana': 'https://fal.run/fal-ai/nano-banana'
};

export async function generateFalImage(
  prompt: string,
  settings: ImageGenerationSettings
): Promise<string> {
  if (!FAL_KEY) {
    throw new Error("FAL_KEY is missing. Please configure your environment variables.");
  }

  const endpoint = ENDPOINTS[settings.model] || ENDPOINTS['flux-dev'];

  // Map aspect ratio to Fal's expected image_size
  let imageSize: string = "landscape_4_3";
  switch (settings.aspectRatio) {
    case '1:1': imageSize = "square_hd"; break;
    case '16:9': imageSize = "landscape_16_9"; break;
    case '9:16': imageSize = "portrait_16_9"; break;
    case '4:3': imageSize = "landscape_4_3"; break;
    case '3:4': imageSize = "portrait_4_3"; break;
    default: imageSize = "landscape_4_3";
  }

  const body: any = {
    prompt: prompt,
    image_size: imageSize,
    enable_safety_checker: true,
    output_format: settings.outputFormat || 'jpeg',
    sync_mode: true
  };

  // Model specific parameters
  if (settings.model === 'flux-dev') {
    body.num_inference_steps = 28;
    body.guidance_scale = 3.5;
  } else if (settings.model === 'nano-banana') {
    // Nano Banana optimized settings
  }

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Key ${FAL_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Fal AI Error ${response.status}: ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    if (data.images && data.images.length > 0) {
      return data.images[0].url;
    }
    throw new Error("No image returned from Fal AI");
  } catch (error) {
    console.error("Fal Image Generation Failed:", error);
    throw error;
  }
}

export async function editFalImage(
  prompt: string,
  imageBase64: string,
  settings: ImageGenerationSettings
): Promise<string> {
    if (!FAL_KEY) {
        throw new Error("FAL_KEY is missing.");
    }

    // Determine endpoint based on model
    let endpoint = 'https://fal.run/fal-ai/flux/dev/image-to-image';
    if (settings.model === 'nano-banana') {
        endpoint = 'https://fal.run/fal-ai/nano-banana/edit'; 
    }

    const body: any = {
        prompt: prompt,
        image_url: imageBase64,
        sync_mode: true,
        output_format: settings.outputFormat || 'jpeg'
    };

    if (settings.model === 'flux-dev') {
        body.strength = 0.85;
        body.num_inference_steps = 30;
        body.guidance_scale = 3.5;
    } else {
        // Nano Banana Edit Params
        // Often uses 'mask' or 'strength' depending on specific API flavor, 
        // assuming standard img2img/edit params for now.
        body.strength = 0.7; 
    }

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Authorization': `Key ${FAL_KEY}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(`Fal AI Edit Error ${response.status}: ${JSON.stringify(errorData)}`);
        }

        const data = await response.json();
        // Nano Banana Edit endpoint structure check
        if (data.image) {
            return data.image.url;
        }
        if (data.images && data.images.length > 0) {
            return data.images[0].url;
        }
        throw new Error("No image returned from Fal AI");

    } catch (error) {
        console.error("Fal Image Edit Failed:", error);
        throw error;
    }
}